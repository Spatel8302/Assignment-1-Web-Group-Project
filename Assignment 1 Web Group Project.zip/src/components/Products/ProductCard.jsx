import { useState } from 'react';
import { Card, CardContent, Typography, Button, Box } from '@mui/material';
import ProductModal from './ProductModal';

const ProductCard = ({ product }) => {
  const [modalOpen, setModalOpen] = useState(false);

  return (
    <>
      <Card sx={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        cursor: 'pointer',
        '&:hover': {
          transform: 'translateY(-4px)',
          boxShadow: 4
        },
        transition: 'transform 0.2s, box-shadow 0.2s'
      }}
      onClick={() => setModalOpen(true)}
      >
        <CardContent sx={{ flexGrow: 1, textAlign: 'center' }}>
          <Typography variant="h2" sx={{ mb: 2 }}>{product.emoji}</Typography>
          <Typography gutterBottom variant="h5">{product.name}</Typography>
          <Typography variant="h6" color="primary" gutterBottom>
            ${product.price.toFixed(2)}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {product.description}
          </Typography>
        </CardContent>
        <Box sx={{ p: 2 }}>
          <Button variant="contained" fullWidth>
            View Details
          </Button>
        </Box>
      </Card>

      <ProductModal
        product={product}
        open={modalOpen}
        onClose={() => setModalOpen(false)}
      />
    </>
  );
};

export default ProductCard;
