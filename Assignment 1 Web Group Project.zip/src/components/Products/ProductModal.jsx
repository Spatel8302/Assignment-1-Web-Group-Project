import { useState } from 'react';
import {
  Modal, Box, Typography, Button, TextField, List, ListItem,
  ListItemText, Divider, IconButton
} from '@mui/material';
import { Close } from '@mui/icons-material';
import { useShop } from '../../context/ShopContext';
import Comments from '../Comments/Comments';

const ProductModal = ({ product, open, onClose }) => {
  const [quantity, setQuantity] = useState(1);
  const { dispatch } = useShop();

  const handleAddToCart = () => {
    dispatch({
      type: 'ADD_TO_CART',
      payload: { ...product, quantity }
    });
    onClose();
  };

  return (
    <Modal open={open} onClose={onClose}>
      <Box sx={{
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        bgcolor: 'background.paper',
        boxShadow: 24,
        p: 4,
        width: '90%',
        maxWidth: 800,
        maxHeight: '90vh',
        overflow: 'auto'
      }}>
        <IconButton
          sx={{ position: 'absolute', right: 8, top: 8 }}
          onClick={onClose}
        >
          <Close />
        </IconButton>

        <Typography variant="h1" align="center" sx={{ mb: 4 }}>{product.emoji}</Typography>
        <Typography variant="h4" gutterBottom>{product.name}</Typography>
        <Typography variant="h6" color="primary" gutterBottom>${product.price.toFixed(2)}</Typography>
        <Typography variant="body1" paragraph>{product.description}</Typography>

        <Typography variant="h6" gutterBottom>Specifications:</Typography>
        <List>
          {product.specs.map((spec, index) => (
            <ListItem key={index}>
              <ListItemText primary={spec} />
            </ListItem>
          ))}
        </List>

        <Box sx={{ my: 3 }}>
          <TextField
            type="number"
            label="Quantity"
            value={quantity}
            onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value)))}
            size="small"
            sx={{ mr: 2 }}
          />
          <Button variant="contained" onClick={handleAddToCart}>
            Add to Cart
          </Button>
        </Box>

        <Divider sx={{ my: 3 }} />

        <Comments productId={product.id} />
      </Box>
    </Modal>
  );
};

export default ProductModal;
