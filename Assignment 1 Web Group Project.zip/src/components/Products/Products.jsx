import { Grid, Typography, Box, CircularProgress } from '@mui/material';
import ProductCard from './ProductCard';
import { useShop } from '../../context/ShopContext';

const Products = () => {
  const { state } = useShop();

  if (state.loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (!state.products?.length) {
    return (
      <Box sx={{ textAlign: 'center', py: 8 }}>
        <Typography variant="h5" gutterBottom>No products available</Typography>
        <Typography color="text.secondary">
          Please check back later for our updated inventory
        </Typography>
      </Box>
    );
  }

  return (
    <Box>
      <Typography variant="h4" gutterBottom sx={{ mb: 4 }}>Our Products</Typography>
      <Grid container spacing={4}>
        {state.products.map(product => (
          <Grid item xs={12} sm={6} md={4} key={product.id}>
            <ProductCard product={product} />
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default Products;
