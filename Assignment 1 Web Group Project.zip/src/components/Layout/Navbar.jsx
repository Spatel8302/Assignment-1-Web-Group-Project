import { AppBar, Toolbar, Typography, Button, Badge, IconButton, Menu, MenuItem } from '@mui/material';
import { ShoppingCart, Person } from '@mui/icons-material';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useShop } from '../../context/ShopContext';

const Navbar = () => {
  const navigate = useNavigate();
  const { state, dispatch } = useShop();
  const [anchorEl, setAnchorEl] = useState(null);

  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleLogout = () => {
    dispatch({ type: 'LOGOUT' });
    handleClose();
    navigate('/');
  };

  return (
    <AppBar position="static">
      <Toolbar>
        <Typography variant="h6" sx={{ flexGrow: 1, cursor: 'pointer' }} onClick={() => navigate('/')}>
          Computer Store
        </Typography>
        <Button color="inherit" onClick={() => navigate('/products')}>Products</Button>
        <IconButton color="inherit" onClick={() => navigate('/cart')}>
          <Badge badgeContent={state.cart.reduce((sum, item) => sum + item.quantity, 0)} color="secondary">
            <ShoppingCart />
          </Badge>
        </IconButton>
        {state.user ? (
          <>
            <IconButton color="inherit" onClick={handleMenu}>
              <Person />
            </IconButton>
            <Typography variant="body1" sx={{ ml: 1 }}>
              {state.user.name}
            </Typography>
            <Menu
              anchorEl={anchorEl}
              open={Boolean(anchorEl)}
              onClose={handleClose}
            >
              <MenuItem onClick={() => { handleClose(); navigate('/account'); }}>
                My Account
              </MenuItem>
              <MenuItem onClick={handleLogout}>Logout</MenuItem>
            </Menu>
          </>
        ) : (
          <Button color="inherit" onClick={() => navigate('/login')}>
            Login
          </Button>
        )}
      </Toolbar>
    </AppBar>
  );
};

export default Navbar;
