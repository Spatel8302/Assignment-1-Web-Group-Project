import { TextField, Button, Typography, Box, Paper } from '@mui/material';

const Register = () => {
  return (
    <Box sx={{ display: 'flex', justifyContent: 'center', minHeight: '80vh' }}>
      <Paper elevation={3} sx={{ p: 4, width: '100%', maxWidth: 400 }}>
        <Typography variant="h4" gutterBottom align="center">Register</Typography>
        <TextField fullWidth label="Name" margin="normal" />
        <TextField fullWidth label="Email" margin="normal" />
        <TextField fullWidth label="Password" type="password" margin="normal" />
        <Button fullWidth variant="contained" sx={{ mt: 3 }}>Register</Button>
      </Paper>
    </Box>
  );
};

export default Register;
