import { useState } from 'react';
import { TextField, Button, Typography, Box, Paper, Alert, Link } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useShop } from '../../context/ShopContext';
import { demoUsers } from '../../data/users';

const Login = () => {
  const navigate = useNavigate();
  const { dispatch } = useShop();
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    const user = demoUsers.find(u => u.email === formData.email && u.password === formData.password);

    if (user) {
      dispatch({
        type: 'LOGIN',
        payload: {
          id: user.id,
          name: user.name,
          email: user.email,
          address: user.address
        }
      });
      navigate(-1);
    } else {
      setError('Invalid credentials. Try demo@example.com / demo123');
    }
  };

  return (
    <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '80vh' }}>
      <Paper elevation={3} sx={{ p: 4, width: '100%', maxWidth: 400 }}>
        <Typography variant="h4" gutterBottom align="center">Login</Typography>

        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

        <Alert severity="info" sx={{ mb: 2 }}>
          Demo credentials:
          <br />
          Email: demo@example.com
          <br />
          Password: demo123
        </Alert>

        <form onSubmit={handleSubmit}>
          <TextField
            fullWidth
            label="Email"
            name="email"
            type="email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            margin="normal"
            required
          />
          <TextField
            fullWidth
            label="Password"
            name="password"
            type="password"
            value={formData.password}
            onChange={(e) => setFormData({ ...formData, password: e.target.value })}
            margin="normal"
            required
          />
          <Button
            type="submit"
            fullWidth
            variant="contained"
            sx={{ mt: 3 }}
          >
            Login
          </Button>
          <Button
            fullWidth
            variant="text"
            onClick={() => navigate('/register')}
            sx={{ mt: 1 }}
          >
            Create Account
          </Button>
          <Box sx={{ mt: 2, textAlign: 'center' }}>
            <Link
              component="button"
              variant="body2"
              onClick={() => navigate(-1)}
            >
              Continue as Guest
            </Link>
          </Box>
        </form>
      </Paper>
    </Box>
  );
};

export default Login;
