import { useState } from 'react';
import { Box, Typography, Rating, TextField, Button, Alert, IconButton, Avatar, Divider } from '@mui/material';
import { PhotoCamera } from '@mui/icons-material';
import { useShop } from '../../context/ShopContext';
import { useNavigate } from 'react-router-dom';

const Comments = ({ productId }) => {
  const { state, dispatch } = useShop();
  const navigate = useNavigate();
  const [comment, setComment] = useState('');
  const [rating, setRating] = useState(5);
  const [image, setImage] = useState(null);
  const [error, setError] = useState('');

  const product = state.products.find(p => p.id === productId);
  const hasPurchased = state.purchaseHistory.some(p => p.productId === productId);

  const handleImageUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setImage(reader.result);
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = () => {
    if (!state.user) {
      setError('Please login to add comments');
      return;
    }

    if (!hasPurchased) {
      setError('You must purchase this product to leave a review');
      return;
    }

    if (!comment.trim()) {
      setError('Please enter a comment');
      return;
    }

    dispatch({
      type: 'ADD_COMMENT',
      payload: {
        productId,
        comment: {
          text: comment,
          rating,
          date: new Date().toISOString(),
          id: Date.now(),
          image,
          userId: state.user.id,
          userName: state.user.name
        }
      }
    });

    setComment('');
    setRating(5);
    setImage(null);
    setError('');
  };

  return (
    <Box sx={{ mt: 4 }}>
      <Typography variant="h5" gutterBottom>Customer Reviews</Typography>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      {state.user ? (
        <Box sx={{ mb: 4 }}>
          <Rating
            value={rating}
            onChange={(_, newValue) => setRating(newValue)}
            sx={{ mb: 2 }}
          />
          <TextField
            fullWidth
            multiline
            rows={3}
            label="Write your review"
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            sx={{ mb: 2 }}
          />
          <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
            <Button
              variant="outlined"
              component="label"
              startIcon={<PhotoCamera />}
            >
              Add Photo
              <input
                type="file"
                hidden
                accept="image/*"
                onChange={handleImageUpload}
              />
            </Button>
            {image && (
              <Box
                component="img"
                src={image}
                alt="Preview"
                sx={{ height: 60, width: 60, objectFit: 'cover', borderRadius: 1 }}
              />
            )}
          </Box>
          <Button variant="contained" onClick={handleSubmit}>
            Post Review
          </Button>
        </Box>
      ) : (
        <Box sx={{ mb: 4 }}>
          <Alert severity="info">
            Please{' '}
            <Button
              color="primary"
              onClick={() => navigate('/login')}
              sx={{ px: 1, py: 0, minWidth: 'auto' }}
            >
              login
            </Button>{' '}
            to write a review
          </Alert>
        </Box>
      )}

      {product?.comments.length === 0 ? (
        <Typography color="text.secondary">No reviews yet</Typography>
      ) : (
        product?.comments.map((comment) => (
          <Box key={comment.id} sx={{ mb: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
              <Avatar>{comment.userName?.[0] || '?'}</Avatar>
              <Box>
                <Typography variant="subtitle2">
                  {comment.userName}
                  {comment.verified && ' ✓'}
                </Typography>
                <Rating value={comment.rating} readOnly size="small" />
              </Box>
              <Typography variant="caption" sx={{ ml: 'auto' }}>
                {new Date(comment.date).toLocaleDateString()}
              </Typography>
            </Box>
            <Typography paragraph sx={{ ml: 7 }}>
              {comment.text}
            </Typography>
            {comment.image && (
              <Box
                component="img"
                src={comment.image}
                alt="Review"
                sx={{
                  ml: 7,
                  maxWidth: '100%',
                  maxHeight: 200,
                  objectFit: 'contain',
                  borderRadius: 1
                }}
              />
            )}
            <Divider sx={{ mt: 2 }} />
          </Box>
        ))
      )}
    </Box>
  );
};

export default Comments;
