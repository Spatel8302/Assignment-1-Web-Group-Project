import { TextField, Button, Rating, Box, Typography } from '@mui/material';
import { useState } from 'react';

const CommentForm = () => {
  const [rating, setRating] = useState(0);

  return (
    <Box>
      <Typography component="legend">Your Rating</Typography>
      <Rating
        name="product-rating"
        value={rating}
        onChange={(event, newValue) => setRating(newValue)}
        sx={{ mb: 2 }}
      />
      <TextField
        fullWidth
        multiline
        rows={4}
        label="Your Review"
        variant="outlined"
        margin="normal"
      />
      <Button variant="contained" sx={{ mt: 2 }}>
        Submit Review
      </Button>
    </Box>
  );
};

export default CommentForm;
