import { Card, CardContent, Typography, IconButton, TextField, Box } from '@mui/material';
import { Delete } from '@mui/icons-material';
import { useShop } from '../../context/ShopContext';

const CartItem = ({ item }) => {
  const { dispatch } = useShop();

  const handleQuantityChange = (newQuantity) => {
    dispatch({
      type: 'UPDATE_QUANTITY',
      payload: { id: item.id, quantity: Math.max(1, parseInt(newQuantity)) }
    });
  };

  const handleRemove = () => {
    dispatch({ type: 'REMOVE_FROM_CART', payload: item.id });
  };

  return (
    <Card sx={{ mb: 2 }}>
      <CardContent>
        <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 2 }}>
          <Typography variant="h2" sx={{ fontSize: '2rem' }}>{item.emoji}</Typography>
          <Box sx={{ flexGrow: 1 }}>
            <Typography variant="h6">{item.name}</Typography>
            <Typography color="primary">${item.price.toFixed(2)}</Typography>
            <Box sx={{ mt: 2, display: 'flex', alignItems: 'center', gap: 2 }}>
              <TextField
                type="number"
                label="Quantity"
                value={item.quantity}
                onChange={(e) => handleQuantityChange(e.target.value)}
                size="small"
                inputProps={{ min: 1 }}
                sx={{ width: 100 }}
              />
              <Typography variant="body2" color="text.secondary">
                Subtotal: ${(item.price * item.quantity).toFixed(2)}
              </Typography>
              <IconButton onClick={handleRemove} color="error" sx={{ ml: 'auto' }}>
                <Delete />
              </IconButton>
            </Box>
          </Box>
        </Box>
      </CardContent>
    </Card>
  );
};

export default CartItem;
