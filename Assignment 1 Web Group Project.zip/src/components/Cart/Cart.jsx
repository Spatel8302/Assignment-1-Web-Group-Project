import { Typography, Button, Box, Grid, Paper, Alert } from '@mui/material';
import CartItem from './CartItem';
import { useShop } from '../../context/ShopContext';
import { useNavigate } from 'react-router-dom';
import { useState } from 'react';

const Cart = () => {
  const { state, dispatch } = useShop();
  const navigate = useNavigate();
  const [showSuccess, setShowSuccess] = useState(false);

  const total = state.cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const handleCheckout = () => {
    if (!state.user && total > 0) {
      navigate('/login');
      return;
    }

    dispatch({ type: 'COMPLETE_PURCHASE' });
    setShowSuccess(true);
    setTimeout(() => {
      setShowSuccess(false);
      navigate('/products');
    }, 2000);
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom>Shopping Cart</Typography>

      {showSuccess && (
        <Alert severity="success" sx={{ mb: 2 }}>
          Purchase completed successfully!
        </Alert>
      )}

      {state.cart.length === 0 ? (
        <Typography>Your cart is empty</Typography>
      ) : (
        <Grid container spacing={4}>
          <Grid item xs={12} md={8}>
            {state.cart.map(item => (
              <CartItem key={item.id} item={item} />
            ))}
          </Grid>
          <Grid item xs={12} md={4}>
            <Paper elevation={3} sx={{ p: 3 }}>
              <Typography variant="h6" gutterBottom>
                Total: ${total.toFixed(2)}
              </Typography>
              {!state.user && (
                <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                  You can checkout as a guest or login to save your purchase history
                </Typography>
              )}
              <Button
                variant="contained"
                fullWidth
                onClick={handleCheckout}
                disabled={state.cart.length === 0}
              >
                {state.user ? 'Complete Purchase' : 'Continue as Guest'}
              </Button>
            </Paper>
          </Grid>
        </Grid>
      )}
    </Box>
  );
};

export default Cart;
