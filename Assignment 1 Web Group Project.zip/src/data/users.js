export const demoUsers = [
  {
    id: 1,
    email: 'demo@example.com',
    password: 'demo123',
    name: 'Demo User',
    address: '123 Demo Street'
  },
  {
    id: 2,
    email: 'test@example.com',
    password: 'test123',
    name: 'Test User',
    address: '456 Test Avenue'
  }
];
