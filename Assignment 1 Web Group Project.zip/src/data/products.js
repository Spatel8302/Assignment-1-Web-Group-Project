export const products = [
  {
    id: 1,
    name: "Gaming Laptop Pro",
    emoji: "💻",
    price: 1299.99,
    description: "High-performance gaming laptop with RTX 3070",
    specs: ["16GB RAM", "1TB SSD", "15.6\" 144Hz Display"],
    comments: []
  },
  {
    id: 2,
    name: "4K Monitor",
    emoji: "🖥️",
    price: 399.99,
    description: "32-inch 4K Ultra HD Monitor",
    specs: ["4K Resolution", "1ms Response Time", "HDR Support"],
    comments: []
  },
  {
    id: 3,
    name: "Mechanical Keyboard",
    emoji: "⌨️",
    price: 149.99,
    description: "RGB Mechanical Gaming Keyboard",
    specs: ["Cherry MX Switches", "Per-key RGB", "Aluminum Frame"],
    comments: []
  },
  {
    id: 4,
    name: "Gaming Mouse",
    emoji: "🖱️",
    price: 79.99,
    description: "Wireless Gaming Mouse with RGB",
    specs: ["20K DPI Sensor", "Wireless", "50hr Battery Life"],
    comments: []
  },
  {
    id: 5,
    name: "Gaming Headset",
    emoji: "🎧",
    price: 129.99,
    description: "7.1 Surround Sound Gaming Headset",
    specs: ["7.1 Surround", "Noise-canceling Mic", "Memory Foam"],
    comments: []
  }
];
