import { createContext, useContext, useReducer } from 'react';
import { products as initialProducts } from '../data/products';

const ShopContext = createContext();
export const useShop = () => useContext(ShopContext);

const initialState = {
  products: initialProducts,
  cart: [],
  user: null,
  loading: false,
  error: null,
  purchaseHistory: []
};

const shopReducer = (state, action) => {
  switch (action.type) {
    case 'ADD_TO_CART': {
      const existingItem = state.cart.find(item => item.id === action.payload.id);
      if (existingItem) {
        return {
          ...state,
          cart: state.cart.map(item =>
            item.id === action.payload.id
              ? { ...item, quantity: item.quantity + action.payload.quantity }
              : item
          )
        };
      }
      return { ...state, cart: [...state.cart, { ...action.payload, quantity: action.payload.quantity || 1 }] };
    }

    case 'UPDATE_QUANTITY':
      return {
        ...state,
        cart: state.cart.map(item =>
          item.id === action.payload.id
            ? { ...item, quantity: action.payload.quantity }
            : item
        )
      };

    case 'REMOVE_FROM_CART':
      return {
        ...state,
        cart: state.cart.filter(item => item.id !== action.payload)
      };

    case 'CLEAR_CART':
      return {
        ...state,
        cart: []
      };

    case 'LOGIN':
      return {
        ...state,
        user: action.payload,
        error: null
      };

    case 'LOGOUT':
      return {
        ...state,
        user: null,
        error: null
      };

    case 'UPDATE_USER':
      return {
        ...state,
        user: { ...state.user, ...action.payload }
      };

    case 'ADD_COMMENT':
      if (!state.user) return state;

      const hasPurchased = state.purchaseHistory.some(
        purchase => purchase.productId === action.payload.productId
      );

      if (!hasPurchased) return state;

      return {
        ...state,
        products: state.products.map(product =>
          product.id === action.payload.productId
            ? {
                ...product,
                comments: [
                  ...product.comments,
                  {
                    ...action.payload.comment,
                    userId: state.user.id,
                    userName: state.user.name,
                    verified: true
                  }
                ]
              }
            : product
        )
      };

    case 'COMPLETE_PURCHASE':
      const purchaseItems = state.cart.map(item => ({
        productId: item.id,
        quantity: item.quantity,
        purchaseDate: new Date().toISOString()
      }));

      return {
        ...state,
        purchaseHistory: [...state.purchaseHistory, ...purchaseItems],
        cart: []
      };

    case 'SET_ERROR':
      return {
        ...state,
        error: action.payload
      };

    default:
      return state;
  }
};

export const ShopProvider = ({ children }) => {
  const [state, dispatch] = useReducer(shopReducer, initialState);

  return (
    <ShopContext.Provider value={{ state, dispatch }}>
      {children}
    </ShopContext.Provider>
  );
};
